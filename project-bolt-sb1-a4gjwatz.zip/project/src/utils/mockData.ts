import { 
  Crop, 
  WeatherData, 
  MarketplaceItem, 
  KnowledgeArticle, 
  CalendarEvent, 
  InventoryItem,
  ForumPost 
} from '../types';

// Mock data for initial development and testing

export const mockCrops: Crop[] = [
  {
    id: '1',
    name: 'Wheat',
    variety: 'Hard Red Winter',
    plantingDate: '2025-03-15',
    harvestDate: '2025-07-20',
    status: 'growing',
    field: 'North Field',
    area: 25,
    expectedYield: 125,
    notes: 'Applied nitrogen fertilizer on April 10.',
    imageUrl: 'https://images.pexels.com/photos/326082/pexels-photo-326082.jpeg'
  },
  {
    id: '2',
    name: 'Corn',
    variety: 'Sweet Corn',
    plantingDate: '2025-04-10',
    harvestDate: '2025-08-15',
    status: 'planted',
    field: 'East Field',
    area: 15,
    expectedYield: 180,
    notes: 'Using drip irrigation system.',
    imageUrl: 'https://images.pexels.com/photos/547263/pexels-photo-547263.jpeg'
  },
  {
    id: '3',
    name: 'Tomatoes',
    variety: 'Roma',
    plantingDate: '2025-05-01',
    harvestDate: '2025-07-30',
    status: 'planning',
    field: 'Greenhouse 2',
    area: 0.5,
    expectedYield: 2.5,
    notes: 'Will use organic fertilizer this season.',
    imageUrl: 'https://images.pexels.com/photos/533280/pexels-photo-533280.jpeg'
  }
];

export const mockWeatherData: WeatherData = {
  temperature: 22,
  condition: 'Partly Cloudy',
  humidity: 65,
  windSpeed: 10,
  precipitation: 20,
  forecast: [
    {
      date: '2025-05-21',
      temperature: {
        min: 18,
        max: 24
      },
      condition: 'Partly Cloudy',
      precipitation: 10
    },
    {
      date: '2025-05-22',
      temperature: {
        min: 17,
        max: 26
      },
      condition: 'Sunny',
      precipitation: 0
    },
    {
      date: '2025-05-23',
      temperature: {
        min: 16,
        max: 27
      },
      condition: 'Sunny',
      precipitation: 0
    },
    {
      date: '2025-05-24',
      temperature: {
        min: 19,
        max: 24
      },
      condition: 'Rain',
      precipitation: 70
    },
    {
      date: '2025-05-25',
      temperature: {
        min: 18,
        max: 22
      },
      condition: 'Rain',
      precipitation: 80
    }
  ]
};

export const mockMarketplaceItems: MarketplaceItem[] = [
  {
    id: '1',
    title: 'Organic Potatoes',
    category: 'crop',
    price: 1.5,
    unit: 'kg',
    quantity: 500,
    seller: 'Green Valley Farm',
    location: 'Riverside County',
    description: 'Freshly harvested organic potatoes. Perfect for restaurants and grocers.',
    imageUrl: 'https://images.pexels.com/photos/144248/potatoes-vegetables-erdfrucht-bio-144248.jpeg',
    postedDate: '2025-05-10'
  },
  {
    id: '2',
    title: 'John Deere Tractor - 2022 Model',
    category: 'equipment',
    price: 45000,
    quantity: 1,
    seller: 'Farm Equipment Supplies',
    location: 'Central Valley',
    description: 'Slightly used John Deere tractor. 500 hours of operation. Excellent condition.',
    imageUrl: 'https://images.pexels.com/photos/2933243/pexels-photo-2933243.jpeg',
    postedDate: '2025-05-15'
  },
  {
    id: '3',
    title: 'Irrigation System Installation',
    category: 'service',
    price: 2500,
    quantity: 1,
    seller: 'Modern Irrigation Co.',
    location: 'Statewide',
    description: 'Professional installation of drip irrigation systems. Includes materials and labor.',
    imageUrl: 'https://images.pexels.com/photos/2464161/pexels-photo-2464161.jpeg',
    postedDate: '2025-05-18'
  }
];

export const mockKnowledgeArticles: KnowledgeArticle[] = [
  {
    id: '1',
    title: 'Sustainable Farming Practices for the Modern Farmer',
    category: 'Sustainability',
    summary: 'Learn about eco-friendly farming approaches that improve soil health and biodiversity.',
    content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
    author: 'Dr. Emily Johnson',
    publishDate: '2025-04-15',
    readTime: 8,
    imageUrl: 'https://images.pexels.com/photos/440731/pexels-photo-440731.jpeg',
    tags: ['sustainable', 'eco-friendly', 'soil health']
  },
  {
    id: '2',
    title: 'Water Conservation Techniques for Dry Seasons',
    category: 'Water Management',
    summary: 'Strategies to conserve water during drought periods while maintaining crop yields.',
    content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
    author: 'Michael Rodriguez',
    publishDate: '2025-05-02',
    readTime: 6,
    imageUrl: 'https://images.pexels.com/photos/414919/pexels-photo-414919.jpeg',
    tags: ['water', 'conservation', 'drought']
  },
  {
    id: '3',
    title: 'Pest Management Without Harmful Chemicals',
    category: 'Pest Control',
    summary: 'Natural methods to control pests and protect your crops without synthetic pesticides.',
    content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
    author: 'Sarah Chen, PhD',
    publishDate: '2025-05-10',
    readTime: 7,
    imageUrl: 'https://images.pexels.com/photos/7728673/pexels-photo-7728673.jpeg',
    tags: ['pest control', 'organic', 'natural']
  }
];

export const mockCalendarEvents: CalendarEvent[] = [
  {
    id: '1',
    title: 'Plant Corn - East Field',
    startDate: '2025-04-10',
    type: 'planting',
    cropId: '2',
    fieldId: 'east',
    notes: 'Use new hybrid seeds',
    completed: true
  },
  {
    id: '2',
    title: 'Apply Fertilizer - North Field',
    startDate: '2025-05-20',
    type: 'fertilizing',
    cropId: '1',
    fieldId: 'north',
    notes: 'Nitrogen-based fertilizer',
    completed: false
  },
  {
    id: '3',
    title: 'Harvest Tomatoes',
    startDate: '2025-07-30',
    endDate: '2025-08-10',
    type: 'harvesting',
    cropId: '3',
    fieldId: 'greenhouse2',
    notes: 'Check for ripeness before harvesting',
    completed: false
  },
  {
    id: '4',
    title: 'Irrigation Maintenance',
    startDate: '2025-06-15',
    type: 'other',
    notes: 'Check all pumps and pipes for leaks',
    completed: false
  }
];

export const mockInventoryItems: InventoryItem[] = [
  {
    id: '1',
    name: 'Corn Seeds - Golden Harvest',
    category: 'seed',
    quantity: 50,
    unit: 'kg',
    purchaseDate: '2025-02-15',
    expiryDate: '2026-02-15',
    supplier: 'AG Seeds Inc.',
    cost: 1200,
    location: 'Storage Room A',
    notes: 'High yield variety'
  },
  {
    id: '2',
    name: 'Organic Fertilizer',
    category: 'fertilizer',
    quantity: 1000,
    unit: 'kg',
    purchaseDate: '2025-03-10',
    supplier: 'Green Earth Co',
    cost: 800,
    location: 'Barn 2',
    notes: 'For vegetable crops'
  },
  {
    id: '3',
    name: 'Irrigation Pipes',
    category: 'equipment',
    quantity: 200,
    unit: 'm',
    purchaseDate: '2024-11-20',
    supplier: 'Farm Supplies Ltd',
    cost: 600,
    location: 'Storage Shed B',
    notes: 'PVC, 2-inch diameter'
  }
];

export const mockForumPosts: ForumPost[] = [
  {
    id: '1',
    title: 'Best time to plant wheat in the southern region?',
    content: 'I\'m new to wheat farming and wondering when the optimal planting time is for our southern climate. Any advice from experienced farmers?',
    author: 'NewFarmer123',
    publishDate: '2025-05-01',
    category: 'Crop Management',
    likes: 12,
    comments: [
      {
        id: '1',
        content: 'In our southern region, I\'ve had the best results planting in early October. Gives enough time before the winter frost.',
        author: 'WheatExpert',
        publishDate: '2025-05-01',
        likes: 5
      },
      {
        id: '2',
        content: 'It depends on your specific microclimate. I\'m in the valley and I plant in late September.',
        author: 'ValleyFarmer',
        publishDate: '2025-05-02',
        likes: 3
      }
    ],
    tags: ['wheat', 'planting', 'seasonal']
  },
  {
    id: '2',
    title: 'Organic solutions for tomato blight?',
    content: 'My tomato plants are showing early signs of blight. I\'m trying to stay organic - any natural solutions that have worked for you?',
    author: 'OrganicTomGrower',
    publishDate: '2025-05-10',
    category: 'Pest Management',
    likes: 24,
    comments: [
      {
        id: '1',
        content: 'I\'ve had success with a mixture of baking soda, mild soap and water as a spray. 1 tablespoon baking soda, 1 teaspoon mild soap to a gallon of water.',
        author: 'GreenThumb',
        publishDate: '2025-05-10',
        likes: 8
      }
    ],
    tags: ['tomatoes', 'organic', 'disease', 'blight']
  }
];