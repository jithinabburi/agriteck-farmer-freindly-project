import React from 'react';
import Navbar from '../components/common/Navbar';
import WeatherWidget from '../components/common/WeatherWidget';
import CropCard from '../components/crops/CropCard';
import CalendarEventCard from '../components/calendar/CalendarEventCard';
import DashboardStats from '../components/dashboard/DashboardStats';
import { Clock, ChevronRight, Plus, Map, ArrowRight, Calendar } from 'lucide-react';
import { mockCrops, mockWeatherData, mockCalendarEvents } from '../utils/mockData';

const Home: React.FC = () => {
  // Get today's date in readable format
  const today = new Date();
  const formattedDate = today.toLocaleDateString('en-US', { 
    weekday: 'long', 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  });

  // Get upcoming calendar events for today and tomorrow
  const todayEvents = mockCalendarEvents.filter(event => {
    const eventDate = new Date(event.startDate);
    return eventDate.toDateString() === today.toDateString() && !event.completed;
  });

  // Handle marking an event as complete
  const handleToggleComplete = (id: string) => {
    console.log(`Toggle event ${id} completion status`);
    // In a real app, we would update the database
    // For now we just console.log
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-800">Farming Dashboard</h1>
            <p className="text-gray-600 flex items-center mt-1">
              <Clock size={16} className="mr-1.5" />
              <span>{formattedDate}</span>
            </p>
          </div>
          <div className="mt-4 md:mt-0 flex space-x-3">
            <button className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors duration-200 flex items-center">
              <Plus size={18} className="mr-1.5" />
              <span>Add Crop</span>
            </button>
            <button className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors duration-200 flex items-center">
              <Map size={18} className="mr-1.5" />
              <span>View Fields</span>
            </button>
          </div>
        </div>
        
        {/* Dashboard Stats */}
        <DashboardStats crops={mockCrops} events={mockCalendarEvents} />
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
          {/* Main content - 2 columns */}
          <div className="lg:col-span-2 space-y-6">
            {/* Welcome Card */}
            <div className="bg-gradient-to-r from-green-700 to-green-600 rounded-lg shadow-md p-6 text-white">
              <h2 className="text-xl font-bold mb-2">Welcome to FarmAssist</h2>
              <p className="mb-4">Your digital farming assistant to help manage your crops, schedule tasks, and maximize productivity.</p>
              <div className="flex space-x-3">
                <button className="bg-white text-green-700 px-4 py-2 rounded-md hover:bg-gray-100 transition-colors duration-200">
                  Watch Tutorial
                </button>
                <button className="border border-white text-white px-4 py-2 rounded-md hover:bg-green-600 transition-colors duration-200">
                  Setup Guide
                </button>
              </div>
            </div>
            
            {/* Active Crops */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-bold text-gray-800">Active Crops</h2>
                <button className="text-green-600 hover:text-green-700 font-medium text-sm flex items-center">
                  <span>View All</span>
                  <ChevronRight size={16} />
                </button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {mockCrops.slice(0, 2).map(crop => (
                  <CropCard key={crop.id} crop={crop} />
                ))}
              </div>
            </div>
            
            {/* Marketplace Preview */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-bold text-gray-800">Marketplace Highlights</h2>
                <button className="text-green-600 hover:text-green-700 font-medium text-sm flex items-center">
                  <span>Go to Marketplace</span>
                  <ArrowRight size={16} className="ml-1" />
                </button>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="bg-blue-50 rounded-lg p-4 flex flex-col items-center justify-center text-center hover:bg-blue-100 transition-colors duration-200">
                  <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center mb-3">
                    <img 
                      src="https://images.pexels.com/photos/144248/potatoes-vegetables-erdfrucht-bio-144248.jpeg" 
                      alt="Crops" 
                      className="w-10 h-10 rounded-full object-cover"
                    />
                  </div>
                  <h3 className="font-medium text-gray-800">Crops & Seeds</h3>
                  <p className="text-sm text-gray-600 mt-1">42 listings</p>
                </div>
                
                <div className="bg-amber-50 rounded-lg p-4 flex flex-col items-center justify-center text-center hover:bg-amber-100 transition-colors duration-200">
                  <div className="w-16 h-16 rounded-full bg-amber-100 flex items-center justify-center mb-3">
                    <img 
                      src="https://images.pexels.com/photos/2933243/pexels-photo-2933243.jpeg" 
                      alt="Equipment" 
                      className="w-10 h-10 rounded-full object-cover"
                    />
                  </div>
                  <h3 className="font-medium text-gray-800">Equipment</h3>
                  <p className="text-sm text-gray-600 mt-1">28 listings</p>
                </div>
                
                <div className="bg-purple-50 rounded-lg p-4 flex flex-col items-center justify-center text-center hover:bg-purple-100 transition-colors duration-200">
                  <div className="w-16 h-16 rounded-full bg-purple-100 flex items-center justify-center mb-3">
                    <img 
                      src="https://images.pexels.com/photos/2464161/pexels-photo-2464161.jpeg" 
                      alt="Services" 
                      className="w-10 h-10 rounded-full object-cover"
                    />
                  </div>
                  <h3 className="font-medium text-gray-800">Services</h3>
                  <p className="text-sm text-gray-600 mt-1">15 listings</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Sidebar - 1 column */}
          <div className="space-y-6">
            {/* Weather Widget */}
            <WeatherWidget weatherData={mockWeatherData} />
            
            {/* Today's Calendar Events */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="bg-blue-600 text-white p-4">
                <h3 className="font-medium text-lg">Today's Tasks</h3>
              </div>
              
              <div className="p-4">
                {todayEvents.length > 0 ? (
                  <div className="space-y-3">
                    {todayEvents.map(event => (
                      <CalendarEventCard 
                        key={event.id} 
                        event={event} 
                        onToggleComplete={() => handleToggleComplete(event.id)}
                      />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-6">
                    <p className="text-gray-500">No tasks for today</p>
                    <button className="mt-3 text-blue-600 hover:text-blue-700 font-medium text-sm">
                      Add New Task
                    </button>
                  </div>
                )}
                
                <div className="mt-4 pt-3 border-t border-gray-100">
                  <button className="w-full px-3 py-2 bg-blue-50 text-blue-600 rounded-md hover:bg-blue-100 transition-colors duration-200 flex items-center justify-center">
                    <Calendar size={16} className="mr-1.5" />
                    <span>View Calendar</span>
                  </button>
                </div>
              </div>
            </div>
            
            {/* Knowledge Base Articles */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="bg-green-600 text-white p-4">
                <h3 className="font-medium text-lg">Farming Tips</h3>
              </div>
              
              <div className="p-4">
                <div className="space-y-3">
                  <div className="p-3 bg-green-50 rounded-md hover:bg-green-100 transition-colors duration-200">
                    <h4 className="font-medium text-gray-800">Sustainable Irrigation Practices</h4>
                    <p className="text-sm text-gray-600 mt-1 line-clamp-2">
                      Learn how to reduce water usage while maintaining crop yields through modern irrigation techniques.
                    </p>
                    <div className="mt-2 flex justify-between items-center">
                      <span className="text-xs text-gray-500">5 min read</span>
                      <button className="text-green-600 text-sm font-medium">Read More</button>
                    </div>
                  </div>
                  
                  <div className="p-3 bg-green-50 rounded-md hover:bg-green-100 transition-colors duration-200">
                    <h4 className="font-medium text-gray-800">Preparing for the Rainy Season</h4>
                    <p className="text-sm text-gray-600 mt-1 line-clamp-2">
                      Strategies to protect your crops and soil from heavy rainfall and prevent erosion.
                    </p>
                    <div className="mt-2 flex justify-between items-center">
                      <span className="text-xs text-gray-500">7 min read</span>
                      <button className="text-green-600 text-sm font-medium">Read More</button>
                    </div>
                  </div>
                </div>
                
                <div className="mt-4 pt-3 border-t border-gray-100">
                  <button className="w-full px-3 py-2 bg-green-50 text-green-600 rounded-md hover:bg-green-100 transition-colors duration-200 flex items-center justify-center">
                    <span>View Knowledge Base</span>
                    <ChevronRight size={16} className="ml-1" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Home;