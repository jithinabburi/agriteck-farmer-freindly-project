import React from 'react';
import { Calendar, Clipboard, MapPin, AlertCircle } from 'lucide-react';
import { CalendarEvent } from '../../types';

interface CalendarEventCardProps {
  event: CalendarEvent;
  onToggleComplete?: (id: string, completed: boolean) => void;
}

const CalendarEventCard: React.FC<CalendarEventCardProps> = ({ 
  event, 
  onToggleComplete 
}) => {
  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      weekday: 'short',
      month: 'short', 
      day: 'numeric' 
    });
  };

  // Get event type icon and color
  const getEventTypeInfo = (type: string) => {
    switch (type) {
      case 'planting':
        return { 
          icon: <Calendar size={18} className="text-green-600" />,
          color: 'bg-green-100 text-green-800'
        };
      case 'harvesting':
        return { 
          icon: <Calendar size={18} className="text-amber-600" />,
          color: 'bg-amber-100 text-amber-800'
        };
      case 'fertilizing':
        return { 
          icon: <Calendar size={18} className="text-blue-600" />,
          color: 'bg-blue-100 text-blue-800'
        };
      case 'pesticide':
        return { 
          icon: <Calendar size={18} className="text-red-600" />,
          color: 'bg-red-100 text-red-800'
        };
      case 'irrigation':
        return { 
          icon: <Calendar size={18} className="text-cyan-600" />,
          color: 'bg-cyan-100 text-cyan-800'
        };
      default:
        return { 
          icon: <Calendar size={18} className="text-gray-600" />,
          color: 'bg-gray-100 text-gray-800'
        };
    }
  };

  // Calculate if event is today, upcoming, or past
  const getEventStatus = () => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const eventDate = new Date(event.startDate);
    eventDate.setHours(0, 0, 0, 0);
    
    const diffTime = eventDate.getTime() - today.getTime();
    const diffDays = diffTime / (1000 * 60 * 60 * 24);
    
    if (diffDays === 0) return 'today';
    if (diffDays < 0) return 'past';
    if (diffDays <= 3) return 'soon';
    return 'upcoming';
  };

  const eventStatus = getEventStatus();
  const { icon, color } = getEventTypeInfo(event.type);
  
  return (
    <div className={`
      bg-white rounded-lg shadow-sm border-l-4 p-3
      ${event.completed ? 'border-gray-300 opacity-75' : ''}
      ${!event.completed && eventStatus === 'today' ? 'border-green-500' : ''}
      ${!event.completed && eventStatus === 'soon' ? 'border-amber-500' : ''}
      ${!event.completed && eventStatus === 'past' ? 'border-red-500' : ''}
      ${!event.completed && eventStatus === 'upcoming' ? 'border-blue-500' : ''}
      transition-all duration-300 hover:shadow-md
    `}>
      <div className="flex justify-between items-start">
        <div className="flex items-start">
          <div className="mr-3 mt-1">
            {icon}
          </div>
          <div>
            <h3 className={`font-medium ${event.completed ? 'text-gray-500 line-through' : 'text-gray-800'}`}>
              {event.title}
            </h3>
            
            <div className="flex items-center mt-1 text-sm text-gray-500">
              <Calendar size={14} className="mr-1" />
              <span>
                {formatDate(event.startDate)}
                {event.endDate && ` - ${formatDate(event.endDate)}`}
              </span>
            </div>
            
            {event.fieldId && (
              <div className="flex items-center mt-1 text-sm text-gray-500">
                <MapPin size={14} className="mr-1" />
                <span>{event.fieldId}</span>
              </div>
            )}
            
            {event.notes && (
              <div className="flex items-center mt-1 text-sm text-gray-500">
                <Clipboard size={14} className="mr-1" />
                <span className="line-clamp-1">{event.notes}</span>
              </div>
            )}
          </div>
        </div>
        
        <div className="flex flex-col items-end">
          <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-medium ${color}`}>
            {event.type.charAt(0).toUpperCase() + event.type.slice(1)}
          </span>
          
          {!event.completed && eventStatus === 'past' && (
            <div className="flex items-center mt-2 text-xs text-red-600">
              <AlertCircle size={12} className="mr-1" />
              <span>Overdue</span>
            </div>
          )}
          
          {!event.completed && eventStatus === 'today' && (
            <div className="flex items-center mt-2 text-xs text-green-600">
              <AlertCircle size={12} className="mr-1" />
              <span>Today</span>
            </div>
          )}
        </div>
      </div>
      
      {onToggleComplete && (
        <div className="mt-3 pt-3 border-t border-gray-100 flex justify-end">
          <div className="flex items-center">
            <input
              type="checkbox"
              id={`complete-${event.id}`}
              checked={event.completed}
              onChange={() => onToggleComplete(event.id, !event.completed)}
              className="rounded text-green-600 focus:ring-green-500 h-4 w-4 mr-2 cursor-pointer"
            />
            <label htmlFor={`complete-${event.id}`} className="text-sm text-gray-600 cursor-pointer">
              Mark as {event.completed ? 'incomplete' : 'complete'}
            </label>
          </div>
        </div>
      )}
    </div>
  );
};

export default CalendarEventCard;