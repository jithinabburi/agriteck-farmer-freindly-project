import React from 'react';
import { Crop, Calendar } from 'lucide-react';
import { Crop as CropType, CalendarEvent } from '../../types';

interface DashboardStatsProps {
  crops: CropType[];
  events: CalendarEvent[];
}

const DashboardStats: React.FC<DashboardStatsProps> = ({ crops, events }) => {
  // Calculate statistics
  const totalCrops = crops.length;
  const activeCrops = crops.filter(crop => 
    crop.status === 'planted' || crop.status === 'growing'
  ).length;
  const totalArea = crops.reduce((sum, crop) => sum + crop.area, 0);
  const expectedYield = crops.reduce((sum, crop) => sum + crop.expectedYield, 0);
  
  // Upcoming events (next 7 days)
  const today = new Date();
  const nextWeek = new Date(today);
  nextWeek.setDate(today.getDate() + 7);
  
  const upcomingEvents = events.filter(event => {
    const eventDate = new Date(event.startDate);
    return eventDate >= today && eventDate <= nextWeek && !event.completed;
  });

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      <div className="bg-white p-4 rounded-lg shadow-sm border-l-4 border-green-500">
        <div className="flex items-center">
          <div className="p-3 bg-green-100 rounded-full mr-4">
            <Crop size={20} className="text-green-600" />
          </div>
          <div>
            <p className="text-sm text-gray-500">Total Crops</p>
            <p className="text-2xl font-bold text-gray-800">{totalCrops}</p>
          </div>
        </div>
        <div className="mt-4 text-sm text-gray-600">
          <span className="font-medium">{activeCrops}</span> actively growing
        </div>
      </div>
      
      <div className="bg-white p-4 rounded-lg shadow-sm border-l-4 border-blue-500">
        <div className="flex items-center">
          <div className="p-3 bg-blue-100 rounded-full mr-4">
            <Crop size={20} className="text-blue-600" />
          </div>
          <div>
            <p className="text-sm text-gray-500">Total Area</p>
            <p className="text-2xl font-bold text-gray-800">{totalArea.toFixed(1)}</p>
          </div>
        </div>
        <div className="mt-4 text-sm text-gray-600">
          Hectares under cultivation
        </div>
      </div>
      
      <div className="bg-white p-4 rounded-lg shadow-sm border-l-4 border-amber-500">
        <div className="flex items-center">
          <div className="p-3 bg-amber-100 rounded-full mr-4">
            <Crop size={20} className="text-amber-600" />
          </div>
          <div>
            <p className="text-sm text-gray-500">Expected Yield</p>
            <p className="text-2xl font-bold text-gray-800">{expectedYield.toFixed(1)}</p>
          </div>
        </div>
        <div className="mt-4 text-sm text-gray-600">
          Tons estimated for harvest
        </div>
      </div>
      
      <div className="bg-white p-4 rounded-lg shadow-sm border-l-4 border-purple-500">
        <div className="flex items-center">
          <div className="p-3 bg-purple-100 rounded-full mr-4">
            <Calendar size={20} className="text-purple-600" />
          </div>
          <div>
            <p className="text-sm text-gray-500">Upcoming Tasks</p>
            <p className="text-2xl font-bold text-gray-800">{upcomingEvents.length}</p>
          </div>
        </div>
        <div className="mt-4 text-sm text-gray-600">
          Due in the next 7 days
        </div>
      </div>
    </div>
  );
};

export default DashboardStats;