import React from 'react';
import { Calendar, Clock, User, Tag } from 'lucide-react';
import { KnowledgeArticle } from '../../types';

interface ArticleCardProps {
  article: KnowledgeArticle;
}

const ArticleCard: React.FC<ArticleCardProps> = ({ article }) => {
  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric' 
    });
  };

  // Get category badge styling
  const getCategoryBadge = (category: string) => {
    const categories: Record<string, string> = {
      'Sustainability': 'bg-green-100 text-green-800',
      'Water Management': 'bg-blue-100 text-blue-800',
      'Pest Control': 'bg-red-100 text-red-800',
      'Soil Health': 'bg-amber-100 text-amber-800',
      'Crop Management': 'bg-emerald-100 text-emerald-800'
    };
    
    return categories[category] || 'bg-gray-100 text-gray-800';
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
      {article.imageUrl && (
        <div className="h-48 overflow-hidden">
          <img 
            src={article.imageUrl} 
            alt={article.title} 
            className="w-full h-full object-cover"
          />
        </div>
      )}
      
      <div className="p-4">
        <div className="mb-3">
          <span className={`inline-block px-2 py-1 rounded-full text-xs font-medium ${getCategoryBadge(article.category)}`}>
            {article.category}
          </span>
        </div>
        
        <h3 className="text-lg font-semibold text-gray-800 mb-2 line-clamp-2">{article.title}</h3>
        
        <p className="text-sm text-gray-600 mb-4 line-clamp-3">
          {article.summary}
        </p>
        
        <div className="grid grid-cols-2 gap-2 mb-4">
          <div className="flex items-center text-xs text-gray-500">
            <User size={14} className="mr-1" />
            <span>{article.author}</span>
          </div>
          
          <div className="flex items-center text-xs text-gray-500">
            <Calendar size={14} className="mr-1" />
            <span>{formatDate(article.publishDate)}</span>
          </div>
          
          <div className="flex items-center text-xs text-gray-500">
            <Clock size={14} className="mr-1" />
            <span>{article.readTime} min read</span>
          </div>
          
          <div className="flex items-center text-xs text-gray-500">
            <Tag size={14} className="mr-1" />
            <span>{article.tags.length} tags</span>
          </div>
        </div>
        
        <div className="flex flex-wrap gap-1 mb-4">
          {article.tags.slice(0, 3).map((tag, index) => (
            <span 
              key={index}
              className="px-2 py-1 bg-gray-100 text-gray-600 rounded-full text-xs"
            >
              #{tag}
            </span>
          ))}
          {article.tags.length > 3 && (
            <span className="px-2 py-1 bg-gray-100 text-gray-600 rounded-full text-xs">
              +{article.tags.length - 3} more
            </span>
          )}
        </div>
        
        <button className="w-full px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors duration-200">
          Read Article
        </button>
      </div>
    </div>
  );
};

export default ArticleCard;