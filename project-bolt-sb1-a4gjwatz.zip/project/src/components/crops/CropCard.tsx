import React from 'react';
import { Calendar, Droplets, ArrowRight, Edit, Trash } from 'lucide-react';
import { Crop } from '../../types';

interface CropCardProps {
  crop: Crop;
  onEdit?: (id: string) => void;
  onDelete?: (id: string) => void;
}

const CropCard: React.FC<CropCardProps> = ({ crop, onEdit, onDelete }) => {
  // Helper function to determine the status color
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'planning':
        return 'bg-blue-100 text-blue-800';
      case 'planted':
        return 'bg-green-100 text-green-800';
      case 'growing':
        return 'bg-emerald-100 text-emerald-800';
      case 'harvested':
        return 'bg-amber-100 text-amber-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  // Format date to be more readable
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric' 
    });
  };

  // Calculate days until harvest
  const calculateDaysUntilHarvest = () => {
    const today = new Date();
    const harvestDate = new Date(crop.harvestDate);
    const diffTime = harvestDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays > 0 ? diffDays : 0;
  };

  // Calculate progress percentage
  const calculateProgress = () => {
    if (crop.status === 'planning') return 0;
    if (crop.status === 'harvested') return 100;
    
    const plantingDate = new Date(crop.plantingDate).getTime();
    const harvestDate = new Date(crop.harvestDate).getTime();
    const today = new Date().getTime();
    
    if (today <= plantingDate) return 0;
    if (today >= harvestDate) return 100;
    
    const totalDuration = harvestDate - plantingDate;
    const elapsedDuration = today - plantingDate;
    return Math.floor((elapsedDuration / totalDuration) * 100);
  };

  const progressPercentage = calculateProgress();

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 hover:-translate-y-1 hover:shadow-lg">
      {crop.imageUrl && (
        <div className="h-40 overflow-hidden relative">
          <img 
            src={crop.imageUrl} 
            alt={crop.name} 
            className="w-full h-full object-cover"
          />
          <div className="absolute top-0 right-0 m-2">
            <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(crop.status)}`}>
              {crop.status.charAt(0).toUpperCase() + crop.status.slice(1)}
            </span>
          </div>
        </div>
      )}
      
      <div className="p-4">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-lg font-semibold text-gray-800">{crop.name}</h3>
            <p className="text-sm text-gray-600">Variety: {crop.variety}</p>
          </div>
          <div className="flex space-x-2">
            {onEdit && (
              <button 
                onClick={() => onEdit(crop.id)}
                className="text-gray-500 hover:text-blue-600 p-1 rounded-full hover:bg-blue-50 transition-colors duration-200"
              >
                <Edit size={16} />
              </button>
            )}
            {onDelete && (
              <button 
                onClick={() => onDelete(crop.id)}
                className="text-gray-500 hover:text-red-600 p-1 rounded-full hover:bg-red-50 transition-colors duration-200"
              >
                <Trash size={16} />
              </button>
            )}
          </div>
        </div>
        
        <div className="mt-3 grid grid-cols-2 gap-3">
          <div className="bg-gray-50 p-2 rounded flex items-center">
            <Calendar size={16} className="text-green-600 mr-2" />
            <div>
              <p className="text-xs text-gray-500">Planting Date</p>
              <p className="text-sm font-medium">{formatDate(crop.plantingDate)}</p>
            </div>
          </div>
          <div className="bg-gray-50 p-2 rounded flex items-center">
            <Calendar size={16} className="text-amber-600 mr-2" />
            <div>
              <p className="text-xs text-gray-500">Harvest Date</p>
              <p className="text-sm font-medium">{formatDate(crop.harvestDate)}</p>
            </div>
          </div>
        </div>
        
        <div className="mt-3">
          <div className="flex justify-between mb-1">
            <span className="text-xs font-medium text-gray-700">Growth Progress</span>
            <span className="text-xs font-medium text-gray-700">{progressPercentage}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
            <div 
              className="bg-green-600 h-2 rounded-full transition-all duration-500 ease-out" 
              style={{ width: `${progressPercentage}%` }}
            ></div>
          </div>
        </div>
        
        <div className="mt-3 flex justify-between items-center">
          <div>
            <p className="text-sm">
              <span className="font-medium">Field:</span> {crop.field}
            </p>
            <p className="text-sm">
              <span className="font-medium">Area:</span> {crop.area} hectares
            </p>
          </div>
          <div className="text-right">
            <p className="text-sm">
              <span className="font-medium">Expected Yield:</span>
            </p>
            <p className="text-sm font-medium text-green-700">{crop.expectedYield} tons</p>
          </div>
        </div>
        
        {crop.status !== 'harvested' && crop.status !== 'planning' && (
          <div className="mt-3 px-3 py-2 bg-blue-50 rounded-md border border-blue-100">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Droplets size={16} className="text-blue-600 mr-2" />
                <span className="text-sm font-medium text-blue-800">Days until harvest</span>
              </div>
              <span className="text-sm font-bold text-blue-800">{calculateDaysUntilHarvest()}</span>
            </div>
          </div>
        )}
        
        {crop.notes && (
          <div className="mt-3 text-sm text-gray-600">
            <p className="font-medium text-gray-700">Notes:</p>
            <p className="line-clamp-2">{crop.notes}</p>
          </div>
        )}
        
        <button className="mt-4 w-full px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors duration-200 flex items-center justify-center">
          <span>View Details</span>
          <ArrowRight size={16} className="ml-2" />
        </button>
      </div>
    </div>
  );
};

export default CropCard;