import React from 'react';
import { MapPin, Calendar, Tag, ExternalLink } from 'lucide-react';
import { MarketplaceItem } from '../../types';

interface MarketplaceCardProps {
  item: MarketplaceItem;
}

const MarketplaceCard: React.FC<MarketplaceCardProps> = ({ item }) => {
  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric' 
    });
  };

  // Get category badge styling
  const getCategoryBadge = (category: string) => {
    switch (category) {
      case 'crop':
        return 'bg-green-100 text-green-800';
      case 'equipment':
        return 'bg-blue-100 text-blue-800';
      case 'livestock':
        return 'bg-amber-100 text-amber-800';
      case 'service':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  // Format price with unit if available
  const formatPrice = () => {
    if (item.unit) {
      return `$${item.price.toFixed(2)}/${item.unit}`;
    }
    return `$${item.price.toFixed(2)}`;
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
      {item.imageUrl && (
        <div className="h-48 overflow-hidden relative">
          <img 
            src={item.imageUrl} 
            alt={item.title} 
            className="w-full h-full object-cover"
          />
          <div className="absolute top-0 right-0 m-2">
            <span className={`px-2 py-1 rounded-full text-xs font-medium ${getCategoryBadge(item.category)}`}>
              {item.category.charAt(0).toUpperCase() + item.category.slice(1)}
            </span>
          </div>
        </div>
      )}
      
      <div className="p-4">
        <h3 className="text-lg font-semibold text-gray-800 mb-2">{item.title}</h3>
        
        <div className="flex justify-between items-center mb-3">
          <div className="flex items-center">
            <Tag size={16} className="text-green-600 mr-1.5" />
            <span className="text-lg font-bold text-green-700">{formatPrice()}</span>
          </div>
          <div className="text-sm text-gray-600">
            Quantity: {item.quantity} {item.unit || ''}
          </div>
        </div>
        
        <div className="mb-3 text-sm text-gray-600 line-clamp-2">
          {item.description}
        </div>
        
        <div className="flex items-center text-sm text-gray-600 mb-2">
          <MapPin size={16} className="text-gray-500 mr-1.5" />
          <span>{item.location}</span>
        </div>
        
        <div className="flex items-center text-sm text-gray-600 mb-3">
          <Calendar size={16} className="text-gray-500 mr-1.5" />
          <span>Posted on {formatDate(item.postedDate)}</span>
        </div>
        
        <div className="bg-gray-50 p-3 rounded-md mb-3">
          <p className="text-sm font-medium text-gray-700">Seller Information</p>
          <p className="text-sm text-gray-600">{item.seller}</p>
        </div>
        
        <div className="flex space-x-2">
          <button className="flex-1 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors duration-200">
            Contact Seller
          </button>
          <button className="px-4 py-2 border border-green-600 text-green-600 rounded-md hover:bg-green-50 transition-colors duration-200 flex items-center">
            <ExternalLink size={16} className="mr-1.5" />
            <span>Details</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default MarketplaceCard;