import React from 'react';
import { Cloud, CloudRain, CloudSnow, Sun, Wind } from 'lucide-react';
import { WeatherData } from '../../types';

interface WeatherWidgetProps {
  weatherData: WeatherData;
}

const WeatherWidget: React.FC<WeatherWidgetProps> = ({ weatherData }) => {
  // Function to get weather icon based on condition
  const getWeatherIcon = (condition: string) => {
    switch (condition.toLowerCase()) {
      case 'sunny':
        return <Sun size={28} className="text-yellow-500" />;
      case 'cloudy':
      case 'partly cloudy':
        return <Cloud size={28} className="text-gray-400" />;
      case 'rain':
      case 'showers':
      case 'thunderstorm':
        return <CloudRain size={28} className="text-blue-500" />;
      case 'snow':
        return <CloudSnow size={28} className="text-blue-200" />;
      default:
        return <Sun size={28} className="text-yellow-500" />;
    }
  };

  // Format date to display day of week
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { weekday: 'short' });
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="bg-green-700 text-white p-4">
        <h3 className="font-medium text-lg">Weather Forecast</h3>
      </div>
      
      {/* Current weather */}
      <div className="p-4 bg-gradient-to-r from-green-50 to-blue-50">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            {getWeatherIcon(weatherData.condition)}
            <div className="ml-3">
              <p className="text-3xl font-bold">{weatherData.temperature}°C</p>
              <p className="text-sm text-gray-600">{weatherData.condition}</p>
            </div>
          </div>
          <div className="text-right">
            <div className="flex items-center text-sm text-gray-600 mb-1">
              <Wind size={16} className="mr-1" />
              <span>{weatherData.windSpeed} km/h</span>
            </div>
            <div className="flex items-center text-sm text-gray-600">
              <CloudRain size={16} className="mr-1" />
              <span>{weatherData.precipitation}%</span>
            </div>
          </div>
        </div>
      </div>

      {/* 5-day forecast */}
      <div className="p-4">
        <h4 className="text-sm font-medium text-gray-500 mb-2">5-Day Forecast</h4>
        <div className="grid grid-cols-5 gap-2">
          {weatherData.forecast.map((day, index) => (
            <div key={index} className="text-center">
              <p className="text-xs font-medium">{formatDate(day.date)}</p>
              <div className="my-2 flex justify-center">
                {getWeatherIcon(day.condition)}
              </div>
              <p className="text-xs">
                <span className="font-medium">{day.temperature.max}°</span>
                <span className="text-gray-500 mx-1">/</span>
                <span className="text-gray-500">{day.temperature.min}°</span>
              </p>
              <p className="text-xs text-gray-500 mt-1">{day.precipitation}%</p>
            </div>
          ))}
        </div>
      </div>
      
      {/* Weather alert or farming advice */}
      {weatherData.precipitation > 50 && (
        <div className="p-3 bg-yellow-50 border-t border-yellow-100">
          <p className="text-sm text-yellow-800">
            <span className="font-medium">Alert:</span> High precipitation expected. Consider postponing field work.
          </p>
        </div>
      )}
    </div>
  );
};

export default WeatherWidget;