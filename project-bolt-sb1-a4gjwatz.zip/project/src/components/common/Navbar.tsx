import React, { useState } from 'react';
import { Menu, X, Car as Farm, User, Sun, Home, BarChart2, Calendar, BookOpen, ShoppingCart, MessageSquare, Package } from 'lucide-react';

interface NavItem {
  name: string;
  icon: React.ReactNode;
  path: string;
}

const navItems: NavItem[] = [
  { name: 'Home', icon: <Home size={20} />, path: '/' },
  { name: 'Crops', icon: <Farm size={20} />, path: '/crops' },
  { name: 'Weather', icon: <Sun size={20} />, path: '/weather' },
  { name: 'Calendar', icon: <Calendar size={20} />, path: '/calendar' },
  { name: 'Marketplace', icon: <ShoppingCart size={20} />, path: '/marketplace' },
  { name: 'Knowledge Base', icon: <BookOpen size={20} />, path: '/knowledge' },
  { name: 'Analytics', icon: <BarChart2 size={20} />, path: '/analytics' },
  { name: 'Inventory', icon: <Package size={20} />, path: '/inventory' },
  { name: 'Community', icon: <MessageSquare size={20} />, path: '/community' },
];

const Navbar: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activePath, setActivePath] = useState('/');

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const handleNavigation = (path: string) => {
    setActivePath(path);
    setIsMenuOpen(false);
    // In a real app, we would use a router to navigate
    // navigation.navigate(path);
  };

  return (
    <nav className="bg-green-800 text-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <Farm className="h-8 w-8 mr-2" />
              <span className="font-bold text-xl">FarmAssist</span>
            </div>
          </div>
          
          {/* Desktop menu */}
          <div className="hidden md:block">
            <div className="ml-10 flex items-center space-x-4">
              {navItems.map((item) => (
                <button
                  key={item.name}
                  onClick={() => handleNavigation(item.path)}
                  className={`${
                    activePath === item.path
                      ? 'bg-green-900 text-white'
                      : 'text-green-100 hover:bg-green-700'
                  } px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200 flex items-center`}
                >
                  <span className="mr-1.5">{item.icon}</span>
                  <span>{item.name}</span>
                </button>
              ))}
            </div>
          </div>
          
          <div className="hidden md:block">
            <button className="bg-green-700 hover:bg-green-600 text-white px-4 py-2 rounded-md text-sm font-medium flex items-center transition-colors duration-200">
              <User size={18} className="mr-1.5" />
              <span>Profile</span>
            </button>
          </div>
          
          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={toggleMenu}
              className="inline-flex items-center justify-center p-2 rounded-md text-green-100 hover:text-white hover:bg-green-700 focus:outline-none"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-green-800 pb-3 pt-2">
          <div className="px-2 space-y-1">
            {navItems.map((item) => (
              <button
                key={item.name}
                onClick={() => handleNavigation(item.path)}
                className={`${
                  activePath === item.path
                    ? 'bg-green-900 text-white'
                    : 'text-green-100 hover:bg-green-700'
                } block px-3 py-2 rounded-md text-base font-medium w-full text-left flex items-center`}
              >
                <span className="mr-3">{item.icon}</span>
                <span>{item.name}</span>
              </button>
            ))}
            <button className="mt-4 w-full bg-green-700 hover:bg-green-600 text-white px-3 py-2 rounded-md text-base font-medium flex items-center">
              <User size={18} className="mr-3" />
              <span>Profile</span>
            </button>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;