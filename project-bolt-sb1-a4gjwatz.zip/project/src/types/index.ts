// Type definitions for the agriculture app

export interface Crop {
  id: string;
  name: string;
  variety: string;
  plantingDate: string;
  harvestDate: string;
  status: 'planning' | 'planted' | 'growing' | 'harvested';
  field: string;
  area: number;
  expectedYield: number;
  notes: string;
  imageUrl?: string;
}

export interface WeatherData {
  temperature: number;
  condition: string;
  humidity: number;
  windSpeed: number;
  precipitation: number;
  forecast: WeatherForecast[];
}

export interface WeatherForecast {
  date: string;
  temperature: {
    min: number;
    max: number;
  };
  condition: string;
  precipitation: number;
}

export interface MarketplaceItem {
  id: string;
  title: string;
  category: 'crop' | 'equipment' | 'livestock' | 'service' | 'other';
  price: number;
  unit?: string;
  quantity: number;
  seller: string;
  location: string;
  description: string;
  imageUrl?: string;
  postedDate: string;
}

export interface KnowledgeArticle {
  id: string;
  title: string;
  category: string;
  summary: string;
  content: string;
  author: string;
  publishDate: string;
  readTime: number;
  imageUrl?: string;
  tags: string[];
}

export interface CalendarEvent {
  id: string;
  title: string;
  startDate: string;
  endDate?: string;
  type: 'planting' | 'harvesting' | 'fertilizing' | 'pesticide' | 'irrigation' | 'other';
  cropId?: string;
  fieldId?: string;
  notes?: string;
  completed: boolean;
}

export interface InventoryItem {
  id: string;
  name: string;
  category: 'seed' | 'fertilizer' | 'pesticide' | 'equipment' | 'tool' | 'other';
  quantity: number;
  unit: string;
  purchaseDate?: string;
  expiryDate?: string;
  supplier?: string;
  cost?: number;
  location?: string;
  notes?: string;
}

export interface ForumPost {
  id: string;
  title: string;
  content: string;
  author: string;
  publishDate: string;
  category: string;
  likes: number;
  comments: ForumComment[];
  tags: string[];
}

export interface ForumComment {
  id: string;
  content: string;
  author: string;
  publishDate: string;
  likes: number;
}